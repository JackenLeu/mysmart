package com.smarthome.entity;

import lombok.Data;

import java.util.List;

@Data
public class KeyFrame {
    private List<Object> keyFrames;

    public List<Object> getKeyFrames() {
        return keyFrames;
    }

    public void setKeyFrames(List<Object> keyFrames) {
        this.keyFrames = keyFrames;
    }

    public KeyFrame() {
    }

    public KeyFrame(List<Object> keyFrames) {
        this.keyFrames = keyFrames;
    }

    @Override
    public String toString() {
        return "KeyFrame{" +
                "keyFrames=" + keyFrames +
                '}';
    }
}
