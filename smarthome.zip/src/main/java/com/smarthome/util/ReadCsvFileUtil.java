package com.smarthome.util;

import com.csvreader.CsvReader;
import com.csvreader.CsvWriter;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class ReadCsvFileUtil {

private static char separator = ',';

    /**
     * 读取CSV文件
     * @param filename:全路径名
     */
    public static List<String[]> readCSV(String filename) throws Exception {
        CsvReader reader = null;
        List<String[]> dataList = new ArrayList<String[]>();
        try {
            //如果生产文件乱码，windows下用gbk，linux用UTF-8
            reader = new CsvReader(filename, separator, Charset.forName("UTF-8"));
            // 读取表头
            reader.readHeaders();
            String[] headArray = reader.getHeaders();//获取标题
            System.out.println("标题：" );
            for (String string : headArray) {
                System.out.print(string + ",");
            }
            System.out.println();
            // 逐条读取记录，直至读完
            while (reader.readRecord()) {
                String[] str = reader.getValues();
                if (str != null && str.length > 0) {
                    dataList.add(str);
                    for (String s : str) {
                        System.out.print(s + ",");
                    }
                    System.out.println();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != reader) {
                reader.close();
            }
        }
        return dataList;
    }

}

