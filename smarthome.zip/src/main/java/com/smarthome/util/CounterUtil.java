package com.smarthome.util;

public interface CounterUtil {
    void addCount();
}
