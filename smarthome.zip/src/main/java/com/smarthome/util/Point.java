package com.smarthome.util;

public class Point {
    double num1,num2;
    Point(double i,double j){
        num1=i;num2=j;
    }
    double getX(){
        return num1;
    }
    double getY(){
        return num2;
    }
}
